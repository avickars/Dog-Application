# Dog-Application

 - Dog Extractor 
 	- determining optimum hyper parameters in non max surpression - Aidan

 	 - using the test data, normalize and compute the area of each bounding box.  Then using k-means - 
 	 	clustering, classify each box as a small, medium and large box.  Then evaluate the model
 	 	on each subclass as small, medium and large.


 - Dog Comparator - Determinging optimum threshold to classify dogs as the same or similar

 	- Test dog comparator within individual breeds. i.e. pull two images from the same breed. See how well 
 		the model performs.  Repeat for other breeds.

 - Dog Breed - Rishab
 	-  Use external data to get some insights on as well as scraped data.

 - All three - Aidan
 	- 1000 lost dogs
 	- 100 found dogs
 	- Is the true match returned in the top n matches


 All three models  - next 
