# Defining the image size to resize images to
IMAGE_SIZE = 416

# Defining the number of epochs to use in mdoel training
NUM_EPOCHS = 20

# Defining the grid size to use 
GRID_SIZE = 13

# Defining the number of anchor boxes
NUM_ANCHOR_BOXES = 7

# Defining the batch size to use during training
BATCH_SIZE = 30